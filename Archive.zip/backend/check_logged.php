<?php 
    include "./config/connect.php";
    if(isset($_SESSION['user'])){
        $valid = true;
    } else {
        $valid = false;
    }
    echo json_encode($valid);
    exit();
?>