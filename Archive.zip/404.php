<!-- Error 404 Section Start -->
<div class="section section-margin">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- Error Form Start -->
                <div class="error_form">
                    <h1 class="title">404</h1>
                    <h2 class="sub-title">Opps! KHÔNG TÌM THẤY TRANG</h2>
                    <p>Trang của bạn không tìm thấy hiện tại.</p>
                    <!-- <form class="search-form-error" action="#">
                        <input class="input-text" placeholder="Search..." type="text">
                        <button class="submit-btn" type="submit"><i class="fa fa-search"></i></button>
                    </form> -->
                    <a class="nav-content btn btn-primary btn-hover-dark rounded-0 m-t-40" id="home" style="border-radius: 20px;">Trở lại trang chủ</a>
                </div>
                <!-- Error Form End -->
            </div>
        </div>
    </div>
</div>
<!-- Error 404 Section End -->