# PHP SHOP ORDER

## Giới thiệu

![Screen Shot 2022-06-13 at 00.13.55.png](https://raw.githubusercontent.com/Zenfection/Image/master/2022/06/13-00-14-14-Screen%20Shot%202022-06-13%20at%2000.13.55.png)

![Screen Shot 2022-06-13 at 00.15.08.png](https://raw.githubusercontent.com/Zenfection/Image/master/2022/06/13-00-15-14-Screen%20Shot%202022-06-13%20at%2000.15.08.png)



![Screen Shot 2022-06-13 at 00.14.51.png](https://raw.githubusercontent.com/Zenfection/Image/master/2022/06/13-00-14-58-Screen%20Shot%202022-06-13%20at%2000.14.51.png)

Sử dụng :

- PHP 8

- MYSQL 8

## Cài đặt
